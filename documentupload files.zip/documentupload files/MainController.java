package com.lnt.mvc.controller;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.FileCopyUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.lnt.mvc.dao.DocumentDAOImpl;
import com.lnt.mvc.model.Document;
import com.lnt.mvc.model.EMI;
import com.lnt.mvc.service.IEMIService;
import com.lnt.utils.LoginUtility;

@Controller
// @RequestMapping("redirect")
public class MainController {
	@Autowired
	IEMIService emiService;
	@Autowired
	SessionFactory sf;
	@Autowired
	private DocumentDAOImpl documentDao;

	@RequestMapping("test")
	public String displayCalc(Model model) {
		model.addAttribute("calculatorValues", new EMI());
		return "emi-calculator";
	}

	@RequestMapping(value = "login", method = RequestMethod.POST)
	public String login(HttpServletRequest request) {

		/*
		 * AbstractApplicationContext ctx = new
		 * ClassPathXmlApplicationContext("servlet-context.xml");
		 * ctx.registerShutdownHook();
		 */
		String uname = request.getParameter("username");
		String pwd = request.getParameter("password");
		LoginUtility util = new LoginUtility(request.getParameter("username"), request.getParameter("password"));
		/*
		 * LoginUtility util = (LoginUtility) ctx.getBean(uname, pwd,
		 * LoginUtility.class);
		 */
		System.out.println(util.isValidUser());
		System.out.println(request.getParameter("username") + "vxd " + request.getParameter("password"));
		return "successful-login";
	}

	@RequestMapping("/calculate")
	public String displayCalculator(Model model) {
		model.addAttribute("calculatorValues", new EMI());
		return "no-login-emi-calculator";
	}

	@RequestMapping("/calculator")
	public String calculate(@ModelAttribute("calculatorValues") EMI e, BindingResult result, ModelMap model) {
		double emi = emiService.calculateEMI(e);
		double totalAmtPayable = emiService.calculateTotalAmtPayable(emi, e.getTenure());
		double totalInterest = emiService.calculateTotalInterest(e.getLoanAmount(), totalAmtPayable);
		model.addAttribute("emi", Math.rint(emi));
		model.addAttribute("TotalInterest", Math.rint(totalInterest));
		model.addAttribute("AmtPayable", Math.rint(totalAmtPayable));
		return "emi-calculator";
	}

	@RequestMapping("emi")
	public String display(Model model) {
		model.addAttribute("calculatorValues", new EMI());
		return "login-emi-calculator";
	}

	@RequestMapping("/index1")
	public String index(Map<String, Object> map) {
		try {
			map.put("document", new Document());
			map.put("documentList", documentDao.list());
		} catch (Exception e) {
			e.printStackTrace();
		}

		return "documents";
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String save(@ModelAttribute("document") Document document, @RequestParam("file") MultipartFile file) {

		System.out.println("Name:" + document.getName());
		System.out.println("Desc:" + document.getDescription());
		System.out.println("File:" + file.getName());
		System.out.println("ContentType:" + file.getContentType());

		try {
			byte[] b = file.getBytes();
			Session session = sf.openSession();
			Blob blob = Hibernate.getLobCreator(session).createBlob(b);
			// Blob blob = Hibernate.createBlob(file.getInputStream());
			document.setFilename(file.getOriginalFilename());
			document.setContentType(file.getContentType());
		} catch (IOException e) {
			e.printStackTrace();
		}

		try {
			System.out.println("in");
			documentDao.save(document);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return "redirect:/index.html";
	}

	@RequestMapping(value = { "/down" }, method = RequestMethod.GET)
	public String downloadDocument(HttpServletResponse response) throws IOException {
		Document doc = documentDao.get(1);
		response.setContentType(doc.getContentType());
		try {
			response.setContentLength((int) doc.getContent().length());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		response.setHeader("Content-Disposition", "attachment; filename=\"" + doc.getName() + "\"");

		FileCopyUtils.copy((InputStream) doc.getContent(), response.getOutputStream());

		return "redirect:/successful-login";
	}

	@RequestMapping("/download")
	// @RequestMapping("/download/{documentId}")
	public String download(HttpServletResponse response) {

		Document doc = documentDao.get(1);
		try {
			response.setHeader("Content-Disposition", "inline;filename=\"" + doc.getFilename() + "\"");
			response.setContentType(doc.getContentType());
			OutputStream out = response.getOutputStream();
			IOUtils.copy(doc.getContent().getBinaryStream(), out);
			System.out.println(out);
			out.flush();
			out.close();

		} catch (IOException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}

	/*
	 * @RequestMapping(value = "/getpdf1", method = RequestMethod.GET) public
	 * ResponseEntity<byte[]> getPDF1() { Document doc = documentDao.get(1);
	 * System.out.println(doc); HttpHeaders headers = new HttpHeaders();
	 * 
	 * headers.setContentType(MediaType.parseMediaType("application/pdf")); String
	 * filename = "pdf1.pdf";
	 * 
	 * headers.add("content-disposition", "inline;filename=" + filename);
	 * 
	 * headers.setContentDispositionFormData(filename, filename);
	 * headers.setCacheControl("must-revalidate, post-check=0, pre-check=0");
	 * ResponseEntity<byte[]> response = null; try { response = new
	 * ResponseEntity<byte[]>(doc.getContent().getBytes(1, (int)
	 * doc.getContent().length()), headers, HttpStatus.OK);
	 * System.out.println(response); } catch (Exception e) { e.printStackTrace(); }
	 * return response; }
	 */

	@RequestMapping("/remove/{documentId}")
	public String remove(@PathVariable("documentId") Integer documentId) {

		documentDao.remove(documentId);

		return "redirect:/index.html";
	}
}
